---
--- CREATE_EXTENSION
---

CREATE EXTENSION pg_stat_statements;
