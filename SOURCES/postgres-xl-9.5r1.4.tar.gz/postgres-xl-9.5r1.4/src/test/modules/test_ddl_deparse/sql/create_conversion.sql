---
--- CREATE_CONVERSION
---

-- Simple test should suffice for this
CREATE CONVERSION myconv FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8;
